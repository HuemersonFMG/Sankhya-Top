class GrupoTecnicos extends React.Component {

    render () {
        return (
            <ListSelectable />
        );
    }

}