SELECT
    RAZAOSOCIAL AS \"label\",
    CODEMP AS \"value\"
    
FROM
    TSIEMP
    
WHERE ROWNUM < 100